import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { RouterModule,Routes,RouterOutlet} from '@angular/router';

import { NuevoComponent } from './components/nuevo/nuevo.component';
import { AdivinaElNumeroComponent } from './adivina-el-numero/adivina-el-numero.component';
import { AgilidadAritmeticaComponent } from './agilidad-aritmetica/agilidad-aritmetica.component';
import { MenuComponent } from './menu/menu.component';
import { ErrorComponent } from './error/error.component';
import { LoginComponent } from './login/login.component';
import { PrincipalComponent } from './principal/principal.component';
import { ListadoDeResultadosComponent } from './listado-de-resultados/listado-de-resultados.component';
import { AdivinaMasListadoComponent } from './adivina-mas-listado/adivina-mas-listado.component';
import {RuteandoModule} from "./ruteando/ruteando.module";

/*const MiRuteo = [{path: 'Error' , component: ErrorComponent},
{path:"Login",component:LoginComponent},{path:"Principal",component:PrincipalComponent,pathMatch:"full"}
,{path:"Adivina",component:AdivinaElNumeroComponent},{path:"Agilidad",component:AgilidadAritmeticaComponent},
{path:"**",component:ErrorComponent},{path:"AdivinaListado",component:ListadoDeResultadosComponent}];
*/

@NgModule({
  declarations: [
    AppComponent,
    NuevoComponent,
    AdivinaElNumeroComponent,
    AgilidadAritmeticaComponent,
    MenuComponent,
    
    ErrorComponent,
    LoginComponent,
    PrincipalComponent,
    ListadoDeResultadosComponent,
    AdivinaMasListadoComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    RuteandoModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
