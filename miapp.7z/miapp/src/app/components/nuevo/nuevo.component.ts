import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuevo',
  templateUrl: './nuevo.component.html',
  styleUrls: ['./nuevo.component.css']
})
export class NuevoComponent implements OnInit {
heroes = 
[{id:0,name:"Superman",villano:false},{id:0,"name":"Batman",villano:false},
{id:0,name:"Hulk",villano:false},{id:0,name:"Iron Man",villano:false},
{id:0,name:"Arrow",villano:false},{id:0,name:"Thor",villano:false},
{id:0,name:"Lintera Verde",villano:false},{id:0,name:"Iron Fist",villano:false},
{id:0,name:"El Guason",villano:true},{id:0,name:"Duende Verde",villano:true}];


  constructor() { }

  ngOnInit() {
  }

}
